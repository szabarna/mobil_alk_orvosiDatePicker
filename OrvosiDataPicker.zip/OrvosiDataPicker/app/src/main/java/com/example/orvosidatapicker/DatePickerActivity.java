package com.example.orvosidatapicker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Objects;

public class DatePickerActivity extends AppCompatActivity {

    private static final String LOG_TAG = DatePickerActivity.class.getName();
    private static final String PREF_KEY = Objects.requireNonNull(DatePickerActivity.class.getPackage()).toString();

    private SharedPreferences userPreferences;
    private FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_picker);

        userPreferences = getSharedPreferences(PREF_KEY, MODE_PRIVATE);

        user = FirebaseAuth.getInstance().getCurrentUser();

        if(user != null) {
            Log.i(LOG_TAG, "Authenticated User!");
        } else {
            Log.d(LOG_TAG, "Unauthenticated User!");
            finish();
        }
    }
}